def summation(a,b):
    return a + b

def subtraction(a, b):
    return a - b

def multiplication(a, b):
    return a * b

