import math
def area_of_rectangle(lenght, height):
    return lenght*height

def area_of_circle(redius):
    return 2*math.pi*redius