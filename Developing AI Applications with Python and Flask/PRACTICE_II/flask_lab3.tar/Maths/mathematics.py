"""
Mathematics module with ADD, SUBTRACT, MUL Functions 
"""

def summation(a, b):
    """
    summation function
    Return : returns add of two args 
    """
    return a + b

def subtraction(a, b):
    """
    Subtraction function definition
    returns: subtraction fo passed args
    """
    return a - b

def multiplication(a, b):
    """
    mult of two args 
    
    """
    return a*b
    