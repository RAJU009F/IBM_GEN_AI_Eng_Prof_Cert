import numpy as np 
a = np.array([2,2,2])
b = np.array([3,3,3])
c = a+ b
print(c)