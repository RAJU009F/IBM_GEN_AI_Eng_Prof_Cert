import numpy as np

a = np.array([1,2])
b = np.array([3,4])
c = a + b
print(c)

message= "Welcome to the world of programming!"
print (message)